import java.util.Random;
import java.util.Scanner;


class Baseball {
	static Scanner keyboard = new Scanner(System.in);
	private String name; 
	private int[] com = new int[3]; //랜덤 값이 들어갈 배열
	private int[] user = new int[3]; //사용자의 답변이 들어갈 배열
	private int strike; //스트라이크
	private int ball; //볼
	private int is_clear = 0;
	private int max_count = 7;
	private int curr_count = 0;
	
	public Baseball(String init_name) {

		
		name = init_name;

	}

	private void set_random(){
		Random rand = new Random();
		int count = 0;
		boolean[] already = new boolean[10]; //랜덤 숫자가 중복인지 확인하기 위해 필요한 boolean 배열

		for(int i = 0; i < 10 ; i++) {
			already[i] = false; //false로 초기화
		}
		
		for (int i = 0; i < 10; i++)
		while(count < 3) {
			int rand_num = rand.nextInt(10);
			if(!already[rand_num]) {
				com[count] = rand_num;
				already[rand_num] = true;
				count++;
			}
		}
	}

	private void set_user_num(){
		
		
		int count = 0;
		while(count != 3){
			System.out.print("Write your " + (count+1) + " number (0~9): ");
			int temp = keyboard.nextInt();
			int flag = 0;
			for(int i = 0; i < count; i++){
				if(user[i] == temp){
					flag = 1;
					break;
				}
			}
			if(temp >= 10 || temp < 0){
				continue;
			}

			if(flag == 1){
				System.out.println("Duplicate!!");
				flag = 0;
			}
			else{
				user[count] = temp;
				count++;
			}
		}
	}

	private void check_num(){
		strike = 0;
		ball = 0;
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 3; j++){
				if (com[i] == user[j]){
					if(i == j) 
						strike++;
					else
						ball++;
				}
			}
		}

		System.out.println("Strike : " + strike + " Ball : " + ball);
		System.out.println("");

		if(strike == 3){
			try{
				Thread.sleep(1000);
				System.out.println("Thanos : I am inevitable.");
				Thread.sleep(1000);
				System.out.println( name + " : I am ... " + name);
				Thread.sleep(1000);
				is_clear = 1;
			}
			catch(InterruptedException e){
				System.exit(0);
			}
		}
 
	}

	public void play(){



  		try{
			Thread.sleep(1000);
			System.out.println("\n\n\"You have to clear END GAME.\"");
			Thread.sleep(1000);
			System.out.println("\"This game is a base ball game.\nYou have to guess three numbers to defeat Thanos!\"\n");
			Thread.sleep(1000);
		}
		catch(InterruptedException e){
			System.exit(0);
		}
		


		set_random();
		//print_com_num();
		while(is_clear != 1){
			for(curr_count = 0; curr_count < max_count; curr_count++){
				if(is_clear == 0){
					set_user_num();
					print_user_num();
					check_num();
				}
			}
		}

	}
	
	public boolean clear(){
		if(is_clear == 1)
			return true;
		else
			return false;
	}
	

	private void print_com_num(){
			System.out.println("{ " + com[0] + " " + com[1] + " " + com[2] + " }");
	}

	private void print_user_num(){
			System.out.println("{ " + user[0] + " " + user[1] + " " + user[2] + " }");
	}	

	

}