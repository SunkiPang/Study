import java.util.Random;
import java.util.Scanner;

public class Odd_Even {
    private int C_number;
    private int P_number;
    private int count=0;
    private String name;
    private static int is_clear = 0;
    private boolean win=false;
    static Scanner keyboard = new Scanner(System.in);
    
    public Odd_Even(String init_name){
        name = init_name;
    }

    public void play() {
        set_game();
        explain();
        while(!win) {
            input();
            isWin();
        }
        
    }
    public void explain() {
		String s1 = "Dr.Strange";
      	if(!name.equals(s1)){

			try{
				Thread.sleep(1000);
				System.out.println("\n\n");
				System.out.println("The ancient one:  Welcome,"+name+" I expected to see you.");
				Thread.sleep(1000);
				System.out.println("The ancient one:  I know you need this time stone....\nbut i can't just hand it over to you.");
				Thread.sleep(1000);
				System.out.println("\nProve that Dr.Strange has sent you. \n\n");
				Thread.sleep(1000);

				System.out.println("This is ODD_EVEN_GAME.");
				System.out.println("Enter 1 if you think the number of computers is odd, or 0 if you think it is even.");
				System.out.println("If you get the numbers within 3 opportunities, you can move on to the next level.");
			}
			catch(InterruptedException e){
					System.exit(0);
			}
			
		}else{
			try{
				Thread.sleep(1000);
				System.out.println("\n\n\n\nHello Dr.Strange I know why you came.");
				Thread.sleep(1000);
				System.out.println("Wanna play the old game we used to play??\n\n");
				Thread.sleep(1000);

				System.out.println("This is ODD_EVEN_GAME.");
				System.out.println("Enter 1 if you think the number of computers is odd, or 0 if you think it is even.");
				System.out.println("If you get the numbers within 3 opportunities, you can move on to the next level.");
			}
			catch(InterruptedException e){
					System.exit(0);
			}			
		}

    }
    
    public boolean isClear() {
        if(count>=3) {
            count=0;
            System.out.println("Failed to clear the game. Start all over again.");
            return false;
        }
        else {
            System.out.println("cleared the game.");
            System.out.println("Prepare for the next game.");
            is_clear = 1;
            return true;
        }
    }
  
    public void isWin() {
        if(C_number==P_number) {
            
            System.out.println("You won the game after "+ count+ " times!");
            if(isClear()) {
                win = true;
				System.out.println("Here is a mind stone. good luck!");
            }
        }
        else  {
            System.out.println("You lost the game.");
            System.out.println("Initializing game.");
            if (count>=3) isClear();

            set_game();

                    }
    }
    public void set_game() {
        count++;
        Random random= new Random();
        C_number=random.nextInt(2);
    }
    public void input() {
        
		//System.out.println("computer Number : "+ C_number);       
		P_number=keyboard.nextInt();
        
    }

    public boolean clear(){
        if(is_clear == 1)
            return true;
        else
            return false;
    }

}