import java.util.*;
public class TTT {
  
  private String name;
  Scanner keyboard = new Scanner(System.in);
    public int clear =0;
	private int is_clear;
public char [] board = new char[9]; 
public int choice1;
public int tie=0;
public char playerMark;
public void ready(){
    char z = 48;
    for(int i =0; i<9;i++){
      
        board[i]=z;
        z++;}
        System.out.println("\n\n[Thor's Mother was waiting for you...]");
        System.out.println("\n Welcome to Asgard!! \n I know what you are looking for");
        System.out.println("\n Reality stone is in this woman's body..\n You have to draw a Magical circle to get it out...");
        System.out.println("\n It won't be easy... \n The stone will try to disturb you finishing the magic circle.");
        System.out.println("\n Make one row or column or diagonal to finish the magic circle.\n\n");

}

public TTT(String init_name){
   name = init_name;

 }
 public void start(){  
    System.out.println("\nWelcome to Tic-Tac-Toe!");
    System.out.println("Player(x) vs computer(o)");
 }
 public void write(){
  
System.out.printf("     |     | \n");
System.out.printf("  "+board[0]+"  |  "+board[1]+"  |  "+board[2]+" \n");
System.out.printf("_____|_____|_____\n");
System.out.printf("     |     | \n");
System.out.printf("  "+board[3]+"  |  "+board[4]+"  |  "+board[5]+" \n");
System.out.printf("_____|_____|_____\n");
System.out.printf("     |     | \n");
System.out.printf("  "+board[6]+"  |  "+board[7]+"  |  "+board[8]+" \n");
System.out.printf("     |     | \n\n\n\n");
  }
  
 public void getUser(){
  Scanner keyboard = new Scanner(System.in);
  System.out.println("your turn!! choose a tile!!");
  choice1 = keyboard.nextInt();
  
  } 

  public int checkLegal(){
  if(choice1<0||choice1>8){
  System.out.println("Error!!");
  return 1;}
  
  if(board[choice1]=='O'||board[choice1]=='X'){
  System.out.println("Error!!");
  return 1;}
  return 0;
}

public char playerMark(){
  if(playerMark=='X')
  playerMark='O';
  
  else
  playerMark='X';
  return playerMark;
}

public void change(){
  board[choice1]=playerMark();
  tie++;
}

public int checkResult(){
  for (int a = 0; a < 8; a++) {
			String line = null;
			switch (a) {
			case 0:
				line = Character.toString(board[0]) +Character.toString(board[1]) +Character.toString(board[2]);
				break;
			case 1:
				line = Character.toString(board[3]) + Character.toString(board[4]) + Character.toString(board[5]);
				break;
			case 2:
				line = Character.toString(board[6]) + Character.toString(board[7]) + Character.toString(board[8]);
				break;
			case 3:
				line = Character.toString(board[0]) + Character.toString(board[3]) + Character.toString(board[6]);
				break;
			case 4:
				line = Character.toString(board[1]) + Character.toString(board[4]) + Character.toString(board[7]);
				break;
			case 5:
				line = Character.toString(board[2]) + Character.toString(board[5]) + Character.toString(board[8]);
				break;
			case 6:
				line = Character.toString(board[2]) + Character.toString(board[4]) + Character.toString(board[6]);
				break;
			case 7:
				line = Character.toString(board[0]) + Character.toString(board[4]) + Character.toString(board[8]);
				break;
			}
			if (line.equals("XXX")) {
				
        		is_clear =1;
        		return 1;
        
			} else if (line.equals("OOO")) {
				
        return 2;
        
			}
      
      
		}
    return 0;
}
public boolean clear(){
  if(is_clear==1)
  	return true;
  else
  	return false;
}
public void getComputer(){


Random random = new Random();
choice1 = random.nextInt(8);

if(board[choice1]=='X'||board[choice1]=='O'){
  getComputer();
}
}



 public void play(){ 
   tie=0;
  ready();
   write();
  while(checkResult()==0 && tie!=9){
   getUser();
  if(checkLegal()==1)
    continue;
   change();
   write();
   checkResult();
   if(tie==9||is_clear==1)
   break;
   getComputer();
   change();
   write();
   checkResult();
  
   }
  
   if(checkResult()==1){
     System.out.println("You won!!");
     is_clear=1;
   }
   else if(checkResult()==2){
     System.out.println("You lost!!");
     
   }
   else if(tie==9)
   System.out.println("tie!!");
  
  }
}