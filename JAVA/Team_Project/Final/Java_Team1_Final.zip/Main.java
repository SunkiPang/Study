import java.util.Random;
import java.util.Scanner;
//file io(to draw thanos)
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;




class Main {
   
  static Scanner keyboard = new Scanner(System.in);
  public static void main(String[] args) {
    
   String name;
     int m;
   String record_name[] = new String[3];
   long record_time[] = new long[3];
   long max_time = 999999;

  for(int i = 0; i < 3 ; i++){
      record_name[i] = null;
      record_time[i] = max_time;
   }

      String file_rank = "rank.txt";
      int record_count = 0;
      Scanner io  = null;
      try{
         io = new Scanner(new File(file_rank)); 
      }
      catch(FileNotFoundException e){
         System.out.println("Error opening file: " + file_rank);
         System.exit(0);
      }
      while(io.hasNextLine()){
         String line = io.nextLine();
         record_name[record_count] = line;
         line = io.nextLine();
         record_time[record_count] = Long.parseLong(line);
         record_count++;
      }


   show_ranking(record_name, record_time);

   MakeID id = new MakeID();
   id.play();
   name = id.get_name();
   
   long start_time = System.currentTimeMillis();

  try{
    System.out.println("\nYour name is " + name);
    Thread.sleep(1000);
    System.out.println("Nick Fury : Here is a space stone, you need 5 stones to meet thanos. \ngood luck! \n");
    Thread.sleep(1000);
  }
  catch(InterruptedException e){
    System.exit(0);
  }



   


   ShowingMenu menu = new ShowingMenu(name);
   RockScissorPaper rsp = new RockScissorPaper(name);
   Baseball base = new Baseball(name);
   GuessingNumber gn = new GuessingNumber(name);
   Odd_Even od = new Odd_Even(name);
   TTT ttt = new TTT(name);
   
   while(true){
      menu.checkClear(rsp);
      menu.checkClear(gn);
      menu.checkClear(od);
    menu.checkClear(ttt);
    
      m = menu.showMenu();
       if(m == -1) m = menu.showMenu();
       else if(m == 1) od.play();
       else if(m == 2) gn.play();
       else if(m == 3) rsp.play();
        else if(m == 4)   ttt.play();
      else if(m == 5) break;
   }

  try{
   Thread.sleep(1000);
   System.out.println("\n\nNick Fury: Since you got this far.. you deserve the last stone"); 
   Thread.sleep(1000);
   System.out.println("\nNick Fury : Here is a soul stone");
   Thread.sleep(1000);
   System.out.println("Nick Fury : You are now in a final stage, here is a power stone ");
   Thread.sleep(1000);
   System.out.println("Nick Fury : You made it! Good luck with thanos!");
   Thread.sleep(1000);
  }
  catch(InterruptedException e){
    System.exit(0);
  }



    String fn = "Thanos0.txt";
    String fn1 = "Game0.txt";

    Scanner inS = null;
    Scanner inS2 = null;

    try{
      inS = new Scanner(new File(fn)); 
      inS2 = new Scanner(new File(fn1));
      }
    catch(FileNotFoundException e){
      System.out.println("Error opening file");
      System.exit(0);
    }
    while(inS.hasNextLine()){
      String line = inS.nextLine();
      System.out.println(line);
    }
    while(inS2.hasNextLine()){
      String line = inS2.nextLine();
      System.out.println(line);
    }

    inS.close();
    inS2.close();


  System.out.println("Are you ready to fight with Thanos?[Y/N]");
      String s= keyboard.nextLine();
      if(s.equalsIgnoreCase("N")){
          try{
            Thread.sleep(1000);
            System.out.println("\nThanos : haha. you're a coward. ");
            Thread.sleep(1000);
            System.out.println("         I will make you disappearfinger snap...");
            Thread.sleep(1000);
            System.out.println("         Now you lose the game. ");
        }
        catch(InterruptedException e){
          System.exit(0);
        }


         //System.out.println("         Game Over ");

         System.exit(0);
      } 


    try{
      Thread.sleep(1000);
      System.out.println("\nThanos : well, well, well look who's here ... ");
      System.out.println("         Are you ready to accept your fate? ");

      Thread.sleep(1000);
      System.out.println("\nDr.Strange : we are in the endgame now. ");
      Thread.sleep(1000);
      System.out.println("Captain America : Avengers!..... Assemble \n");
      }
      catch(InterruptedException e){
        System.exit(0);
      }

   base.play();

	/*
	마지막 스토리 부분 들어가야 하는 부분.

	*/




   //time check

   long end_time = System.currentTimeMillis();
   long play_time = (end_time - start_time)/(long)1000.0;
   int arr_count = 0;
   for(arr_count = 0 ; arr_count < 3; arr_count++){
      if(play_time <= record_time[arr_count]){
         break;
      }
   }

   if(record_time[arr_count] == max_time){
      record_time[arr_count] = play_time;
      record_name[arr_count] = name;
   }

   else if(arr_count == 0){
    push_rank(record_name, record_time, 2, 1);
    push_rank(record_name, record_time, 1, 0);
      record_time[arr_count] = play_time;
      record_name[arr_count] = name;      

   }else if(arr_count == 1){
    push_rank(record_name, record_time, 2, 1);
      record_time[arr_count] = play_time;
      record_name[arr_count] = name;
   }else if(arr_count == 2){
      record_time[arr_count] = play_time;
      record_name[arr_count] = name;
   }


   System.out.println("\nclear time : " + (end_time - start_time)/1000.0 + " sec");

   String fn2 = "FingerSnap0.txt";
   Scanner inS3 = null;
   try{
      inS3 = new Scanner(new File(fn2));
      }
    catch(FileNotFoundException e){
      System.out.println("Error opening file");
      System.exit(0);
    }
    while(inS3.hasNextLine()){
      String line = inS3.nextLine();
      System.out.println(line);
    }



    try {
      FileWriter fw = new FileWriter(file_rank);
      for(int j = 0; j < 3; j++){
        fw.write(record_name[j] + "\n");
        fw.write((int)record_time[j] + "\n");
     }
      fw.close();
    } catch (IOException e) {
      e.printStackTrace();
   }

  show_ranking(record_name, record_time);


   
     
  }

   static void show_ranking(String[] record_name, long[] record_time){

      try{
        Thread.sleep(1000);
        System.out.println(" \n");
       System.out.println("     *     RANKING      *       ");
         System.out.println("________________________________\n");
      for(int i = 0; i < 3; i++){
         System.out.println("\t "+(i+1) + ". " + record_name[i] + " : " + record_time[i] + " (sec)");
      }
      System.out.println("________________________________\n");
      }
      catch(InterruptedException e){
        System.exit(0);
      }
      
  }

  static void push_rank(String[] record_name, long[] record_time, int i1, int i2){
    record_time[i1] = record_time[i2];
      record_name[i1] = record_name[i2];
  }
}