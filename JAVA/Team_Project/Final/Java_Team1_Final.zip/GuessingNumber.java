import java.util.Random;
import java.util.Scanner;

class GuessingNumber{
	static Scanner keyboard = new Scanner(System.in);
	private String userName; 
	private static int is_clear = 0;



	public GuessingNumber(String init_name) {
		userName = init_name;
	}

	public void play(){
		try{
				Thread.sleep(1000);
				System.out.println("\n\n\n" + userName + " : Hmmm, there are too many Hydra members…..");
				Thread.sleep(1000);
				System.out.println(userName + " : I can't fight them all….");
				Thread.sleep(1000);
				System.out.println(userName + " : I think I can handle 7 men without getting caught…");
				Thread.sleep(1000);
				System.out.println( userName + " : Among those 100 guys, I'll have to find out who carries the Mind Stone in 7 chances…!!");
				Thread.sleep(1000);
				System.out.println( userName + " : Lets test the luck of America's butt.\n\n");
				Thread.sleep(1000);
		}
		catch(InterruptedException e){
			System.exit(0);
		}			


       	System.out.println("Welcome, " + userName + "! to the guessing game.\n You will be given 7 chances to guess the number.");
		int flag = 0;

       	while (true) {


			if(flag == 1){
				break;
			}

           	int	randomNumber = new Random().nextInt(100) + 1;
           	int userGuess = 0;
           	System.out.println("A number has been choosen.");
			
           	//System.out.println(randomNumber);
           	for (int chance = 1; chance <= 7; chance++) {
               	System.out.print("Enter your guess: ");
               	userGuess = keyboard.nextInt();
               	if (userGuess == randomNumber) {
                   	System.out.println("Congratulations. You guessed it with " + chance + " tries.");
					System.out.println("Ancient One : Here is a time stone. good luck!");


					flag = 1;
					is_clear = 1;
                   	break;
               	} else if (userGuess > randomNumber) {
                   	System.out.println("Lower!");
               	} else {
                   	System.out.println("Higher!");
              	}
               	if (chance == 7) {
                   	System.out.println("Sorry! You lost all your chances");
                   	System.out.println("The secret number was : " + randomNumber);
               	}
           	}
       	}
   	}
	   
	public boolean clear(){
		if(is_clear == 1)
			return true;
		else
			return false;
	}



}