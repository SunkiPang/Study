import java.util.Scanner;

class RockScissorPaper{
  private boolean c = false;
  private String name;
  static Scanner keyboard = new Scanner(System.in);

  public boolean clear(){
    return c;
  }  

  public RockScissorPaper(String init_name) {

		name = init_name;

  }


  public void set_game(){
    System.out.println("Rock Scissor Paper");
    System.out.println("1.Rock");
    System.out.println("2.Scissor");
    System.out.println("3.Paper");
  }

  public void play(){

		try{
			Thread.sleep(1000);
			System.out.println("\n\nLook!! PETER got the Power Stone!!\n");
			Thread.sleep(1000);
			System.out.println(name+": Yo!! Peter, do you wanna play a game with me?");
			Thread.sleep(1000);
			System.out.println("\n"+name+": If you win, I'll give you this cool brand new MP3 player");
			Thread.sleep(1000);
			System.out.println(name+": If I win, I get the Power Stone");
			Thread.sleep(1000);
			System.out.println("\n"+"PETER: Brand new MP3 Player!? game on dude!! \n\n");
			Thread.sleep(1000);
		}
		catch(InterruptedException e){
			System.exit(0);
		}


    
    
    set_game();
    //System.out.println("How much do you want to play?");
    
    //int k = keyboard.nextInt();
	int k = 3;
    int i = 0;
    int win = 0;
    int tie = 0;
    int lose = 0;
    int playtime=0;
    int chance;
    while(i<k){
      chance = k-i;
      System.out.println("\nPlaytime: "+playtime);
      System.out.println("Chance: "+chance);
      System.out.println("What is your input?");
      int Input = keyboard.nextInt();
      Game Player = new Game(Input);
      if(Input<1||Input>3){
        System.out.println("Please enter the number 1,2 or 3");
        i--;
      }
      else if(Input == 1) Player.Name = "Rock";
      else if(Input == 2) Player.Name = "Scissor"; 
      else if(Input == 3) Player.Name = "Paper";
      Game Computer = new Game((int)(Math.random()*3)+1);
      if(Computer.Number == 1)
      Computer.Name = "Rock";
      else if(Computer.Number == 2)
      Computer.Name = "Scissor";
      else if(Computer.Number == 3)
      Computer.Name = "Paper";

      System.out.println("\n"+name+ " : " + Player.Name);
      System.out.println("PETER : " + Computer.Name);
      if(Player.Number == Computer.Number){
      System.out.println("Draw");
      tie++;
      i--;
      }
      else if(((Player.Number == 1)&&(Computer.Number==2)) || ((Player.Number == 2)&&(Computer.Number == 3)) || ((Player.Number==3)&&(Computer.Number==1))){
      System.out.println("Win");
      win++;
      }
      else if(((Player.Number == 2)&&(Computer.Number==1)) || ((Player.Number == 3)&&(Computer.Number == 2)) || ((Player.Number==1)&&(Computer.Number==3))){
      System.out.println("Lose");
      lose++;
      }
      else System.out.println("This game is invalid game.");
      
      System.out.println("win :"+win+"\tdraw :"+tie+"\tlose :"+lose);
      i++;

      playtime++;
    }
    if(win>k/2){
      System.out.println("\nClear!");
	  System.out.println("\nPETER : Here is a Power Stone. good luck!");
      //clear();
      c = true;
    }
    else {
      System.out.println("fail!");
      c = false;
    }
  }
}

class Game{
  public int Number;
  public String Name;
  public Game(int Input){
    this.Number = Input;
  }
}