import java.util.Random;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class MakeID {
   static Scanner keyboard = new Scanner(System.in);
   private String name;
   private String start;
   //private String[] hero= {"Iron Man","Captain America","Thor","Hulk","Black widow","Hawkeye","Dr.Strange","Spider Man","Falcon","Ant Man","Vision","Scarlet Witch","War Machine","Mantis","Star-Lord","Gamora","Drax","Rocket Raccon","Groot","Black Panther"};
   private String[] hero = new String[20];
   public void play() {


      name_set_array();
      check_Start();
      set_name();



      
   }
   public void name_set_array(){
      String file_name = "Heros.txt";
      int count = 0;
      Scanner io  = null;
      try{
         io = new Scanner(new File(file_name)); 
      }
      catch(FileNotFoundException e){
         System.out.println("Error opening file");
         System.exit(0);
      }
      while(io.hasNextLine()){
         String line = io.nextLine();
         hero[count] = line;
         count++;
      }
   }

   public void check_Start() {
      
      System.out.println("\nDo you want to start The game?[Y/N]");
      start= keyboard.nextLine();
      if(start.equalsIgnoreCase("N")) {
      System.out.println("Thanos: Ha Ha Ha you're a coward\n\t\tI will make you disappearfinger snap. . . \n\t\tnow you lose the game");
      System.exit(0);
    }
    




   }
   public void set_name() {
      Random random= new Random();
      name= hero[random.nextInt(20)];
   }
   public String get_name() {
      return name;   
   }
}